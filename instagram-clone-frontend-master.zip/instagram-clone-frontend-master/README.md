
# Instagram clone using MERN stack

This is the frontend repo built with React. If you are looking for the backend repo : https://github.com/yassinjouao/instagram-clone-backend


## Authors

- [@yassinjouao](https://github.com/yassinjouao)


## Screenshots

![App Screenshot](https://res.cloudinary.com/dpjsvbt9f/image/upload/v1666552270/instaClone_screenshots/instaclone1_q7vak1.png)

![App Screenshot](https://res.cloudinary.com/dpjsvbt9f/image/upload/v1666552454/instaClone_screenshots/instaclone8_pvqtuq.png)

![App Screenshot](https://res.cloudinary.com/dpjsvbt9f/image/upload/v1666552270/instaClone_screenshots/instaclone2_kgmqmm.png)

![App Screenshot](https://res.cloudinary.com/dpjsvbt9f/image/upload/v1666552606/instaClone_screenshots/instaclone9_jlthcy.png)

![App Screenshot](https://res.cloudinary.com/dpjsvbt9f/image/upload/v1666552270/instaClone_screenshots/instaclone3_vlmek2.png)

![App Screenshot](https://res.cloudinary.com/dpjsvbt9f/image/upload/v1666552270/instaClone_screenshots/instaclone4_w4pmxv.png)

![App Screenshot](https://res.cloudinary.com/dpjsvbt9f/image/upload/v1666552270/instaClone_screenshots/instaclone5_jfzfeb.png)

![App Screenshot](https://res.cloudinary.com/dpjsvbt9f/image/upload/v1666552270/instaClone_screenshots/instaclone6_m7itp4.png)

![App Screenshot](https://res.cloudinary.com/dpjsvbt9f/image/upload/v1666552270/instaClone_screenshots/instaclone7_eodcap.png)



